package com.example.projecte019.jiji;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    private static final int pokemon = 789;
    private Button inici;
    long ident = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        inici = (Button) findViewById(R.id.inici);



      /*  String url = "http://my-json-feed";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        mTextView.setText("Response: " + response.toString());
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error

                    }
                });

// Access the RequestQueue through your singleton class.
        MySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest);*/

       /* inici.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)  {
                URL oracle = null;
                try {
                    oracle = new URL("http://www.oracle.com/");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                URLConnection yc;
                try {
                    yc = oracle.openConnection();
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            yc.getInputStream()));
                    String inputLine;
                    while ((inputLine = in.readLine()) != null)
                        Log.d("funciona?", inputLine);
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });*/
       /* try {
            sendGet("https://api.pokemontcg.io/v1/cards");
            JsonObject obj = new JsonObject(response);
        } catch (Exception e) {
            e.printStackTrace();
        }*/

       /* FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                // All your networking logic
                // should be here
            }
        });*/

        // Create URL
        URL pokeEndpoint = null;
        try {
            pokeEndpoint = new URL("https://api.pokemontcg.io/v1/cards");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        // Create connection
        try {
            pokeEndpoint = new URL("https://api.pokemontcg.io/v1/cards");
            HttpsURLConnection myConnection =
                    (HttpsURLConnection) pokeEndpoint.openConnection();
            myConnection.setRequestProperty("accept", "pokemontcgsdk");

           // Log.d("funciona?","" + (myConnection.getResponseCode()));
           // if (myConnection.getResponseCode() == 200) {

                //InputStream responseBody = myConnection.getInputStream();

               /* InputStreamReader responseBodyReader =
                        new InputStreamReader(responseBody, "UTF-8");

                JsonReader jsonReader = new JsonReader(responseBodyReader);

                jsonReader.beginObject(); // Start processing the JSON object
                if (jsonReader.hasNext()) { // Loop through all keys
                    String key = jsonReader.nextName(); // Fetch the next key
                    if (key.equals("id")) { // Check if desired key
                        ident = jsonReader.nextLong();
                        // Fetch the value as a String
                        //String value = jsonReader.nextString();

                        // Do something with the value
                        // ...

                        //break; // Break out of the loop
                    } else {
                        jsonReader.skipValue(); // Skip values of other keys
                    }
                }
                jsonReader.endObject();*/
            //} else {
                // Error handling code goes here
           // }



        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            Intent i = new Intent(this, InfoExtra1.class );
            i.putExtra("direccion", Long.toString(ident));
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

   /* class MyAsyncTask extends AsyncTask<String,Void,JSONObject> {

        @Override
        protected JSONObject doInBackground(String... urls) {
            return RestService.doGet(urls[0]);
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            TextView tv = (TextView) findViewById(R.id.textView);
            tv.setText(jsonObject.toString());
        }
    }*/

/*
    public static String  sendGet(String url) throws Exception {



        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
       /*
        pokemon = require('pokemontcgsdk')

        pokemon.card.find('xy7-54')
                .then(result => {
                console.log(result.card.name)
        })*/
       /* const pokemon = require('pokemontcgsdk');

        pokemon.card.all({ supertype: 'pokemon', types: 'dragon|fire|flying', hp: 'gt100' })
.on('data', function (card) {
            console.log(card.name)
        });*/


        // optional default is GET
       /* con.setRequestMethod("GET");



        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();


        return response.toString(); //here is your response which is in string type, but remember that the format is json.


    }*/
        public static void main(String[] args) throws Exception {
            URL oracle = new URL("http://www.oracle.com/");
            URLConnection yc;
            yc = oracle.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    yc.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                Log.d("funciona?", inputLine);
            in.close();
        }

}

