package com.example.projecte019.jiji;

import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class InfoExtra1 extends AppCompatActivity {
    TextView mytext2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_extra1);

        mytext2 = (TextView)findViewById(R.id.text2);

        Bundle bundle = getIntent().getExtras();
        String dato=bundle.getString("direccion");
        mytext2.setText(dato);
    }
}
