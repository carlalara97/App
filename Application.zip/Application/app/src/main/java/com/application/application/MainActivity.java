package com.application.application;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Pokemon> listapersonas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listapersonas=new ArrayList<Pokemon>();

        for (int i = 1; i <= 20; ++i) { //crea un scroll list
            String[] types = {"grass"};
            String[] atack = {"frenzy plant"};
            int[] damage = {i+100};
            listapersonas.add(new Pokemon("" + (i), i, i+3, types, atack, damage));
        }
        AdaptadorPersonas adaptador = new AdaptadorPersonas(this);
        ListView lv1 = (ListView)findViewById(R.id.list1);
        lv1.setAdapter(adaptador);   //los objetos se recuperaran del adaptador

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  //Hacer accion al presionar el item de la lista
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent j = new Intent(MainActivity.this, InfoExtra.class);
                j.putExtra("Name", listapersonas.get(i).getNombre());
                j.putExtra("Hp", "" + listapersonas.get(i).gethp());
                j.putExtra("npn", "" + listapersonas.get(i).getNationalPokedexNumber());

                for (int k = 0; k < listapersonas.get(i).getTypes().length; ++k) {
                    j.putExtra("type " + k, listapersonas.get(i).getTypes()[k]);
                    j.putExtra("ntype", "" + listapersonas.get(i).getTypes().length);
                }
                for (int k = 0; k < listapersonas.get(i).getAtack().length; ++k) {
                    j.putExtra("atack " + k, listapersonas.get(i).getAtack()[k]);
                    j.putExtra("damage " + k, listapersonas.get(i).getDamageAtack()[k]);
                    j.putExtra("natack", "" + listapersonas.get(i).getAtack().length);
                }
                startActivity(j);
               Toast.makeText(MainActivity.this,"" + listapersonas.get(i).gethp(), Toast.LENGTH_LONG).show();
            }
        });
    }

    class AdaptadorPersonas extends ArrayAdapter<Pokemon> {

        AppCompatActivity appCompatActivity;

        AdaptadorPersonas(AppCompatActivity context) {  //conectarse con la clase java que contiene la estructura de datos de pkm
            super(context, R.layout.pokemon, listapersonas);
            appCompatActivity = context;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = appCompatActivity.getLayoutInflater();
            View item = inflater.inflate(R.layout.pokemon, null);   //para mostrear los items

            TextView textView1 = (TextView)item.findViewById(R.id.textView);
            textView1.setText(listapersonas.get(position).getNombre());

            ImageView imageView1 = (ImageView)item.findViewById(R.id.imageView);
            imageView1.setImageResource(R.mipmap.lupa);
            return(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {   //per a que es mostrin els elements del buscador.xml
        getMenuInflater().inflate(R.menu.buscador, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.lupa) {
            Toast.makeText(this, "Has presionat el buscador", Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
