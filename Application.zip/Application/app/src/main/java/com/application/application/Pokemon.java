package com.application.application;

/**
 * Created by ASUS on 14/09/2018.
 */

public class Pokemon {
    private String nombre;
    private int hp, nationalPokedexNumber;
    private String[] types, atack;
    private int[] damageAtack;


    public Pokemon(String nombre, int hp, int nationalPokedexNumber, String[] types, String[] atack, int[] damageAtack) {
        this.nombre=nombre;
        this.hp = hp;
        this.nationalPokedexNumber = nationalPokedexNumber;
        this.types = types;
        this.atack = atack;
        this.damageAtack = damageAtack;
    }

    public String getNombre() {
        return nombre;
    }

    public int gethp() {
        return hp;
    }

    public int getNationalPokedexNumber() {
        return nationalPokedexNumber;
    }

    public String[] getTypes() {
        return types;
    }

    public String[] getAtack() {
        return atack;
    }

    public int[] getDamageAtack() {
        return damageAtack;
    }
}
