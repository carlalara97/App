package com.application.application;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class InfoExtra extends AppCompatActivity {
    TextView tname, tnum, thp;
    private Spinner stype, satack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_extra);

        tname = (TextView)findViewById(R.id.tvname);
        tnum = (TextView)findViewById(R.id.tvnumber);
        thp = (TextView)findViewById(R.id.tvhp);
        stype = (Spinner) findViewById(R.id.spinner1);
        satack = (Spinner) findViewById(R.id.spinner2);

        Bundle bundle = getIntent().getExtras();
        String dato = bundle.getString("Name");
        tname.setText(dato);

        dato = bundle.getString("Hp");
        thp.setText(dato);

        dato = bundle.getString("npn");
        tnum.setText(dato);

        dato = bundle.getString("ntype");
        int ntype = Integer.parseInt(dato);

        String [] optionTypes = new String[ntype];
        for (int i = 0; i < ntype; ++i) {
            dato = bundle.getString("type " + i);
            optionTypes[i] = dato;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, optionTypes);
        stype.setAdapter(adapter);

        dato = bundle.getString("natack");
        int natack = Integer.parseInt(dato);

        String [] optionAtack = new String[natack];
        for (int i = 0; i < natack; ++i) {
            dato = bundle.getString("atack " + i);
            String dato2 = bundle.getString("damage " + i);
            optionAtack[i] = dato + ": " + dato2 + "dps";
        }

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, optionAtack);
        satack.setAdapter(adapter2);
    }
}
